# ResellOS — Session Init Document
> Read this at the start of every build session. It tells you what ResellOS is, where we are, what the rules are, and what we're working on tonight.

---

## What is ResellOS?

ResellOS is a personal operating system for LEGO resellers — built by one active reseller from 15 months of live experience. It automates the business layer: order intake, true cost basis calculation (across four discount layers), inventory tracking, sales matching, tax recovery reporting, and eventually AI-powered buy/sell intelligence.

**The headline feature:** Automated Washington state sales tax recovery. Active resellers recover $5,000+ per year. External services charge 25% of recovered funds. ResellOS generates the filing-ready report automatically. This is what sells the product to the community.

**Business context:**
- $160K revenue proven, $72K net profit across 15 months of LEGO reselling
- GitHub repo: `theroyalcrate/ResellOS`
- Primary sales channels: Walmart WFS, Amazon, Bricklink, eBay
- Key retailers: LEGO.com (primary), Walmart, Kohl's, Barnes & Noble
- State: Washington (WA sales tax recovery is core feature)
- Costing method: FIFO (default), Specific Identification (premium upgrade)
- Subscription target: $400–600/year per user at community launch

---

## The Stack

| Component | Status | Notes |
|---|---|---|
| Python 3.14 | ✅ Installed | Global install |
| Virtual environment | ⚠️ Pending | S10 — create inside ResellOS folder |
| SQLite | ✅ Installed | Via Python stdlib |
| pdfplumber | ✅ Installed | PDF invoice parsing |
| VS Code | ✅ Running | Primary IDE |
| Claude Code extension | ✅ Installed | Primary AI coding loop |
| GitHub (theroyalcrate/ResellOS) | ✅ Active | Commit after every working agent |
| MCP: filesystem | ⬜ Configure next | Local file read/write |
| MCP: GitHub | ⬜ Configure next | Auto-commit |
| MCP: Gmail | ⬜ Configure next | Invoice ingestion |
| MCP: Google Sheets | ⬜ Configure next | View layer sync |
| SQLite → PostgreSQL | 🔵 Future | Phase 6, community launch |

---

## Phase Status

| Phase | Title | Status |
|---|---|---|
| P0 | Foundation | ✅ COMPLETE |
| P1 | Database + Order Flow | 🟡 UP NEXT — Week 1 |
| P2 | Cost Basis Engine Complete | ⬜ Weeks 5–7 |
| P3 | Sales Import + Tax Recovery | ⬜ Weeks 8–11 |
| P4 | Output Layer | ⬜ Weeks 12–13 |
| P5 | Polish + Testing + Historical Data | ⬜ Weeks 14–15 |
| P6 | Community Launch | ⬜ Weeks 16–20 |
| P7 | Keepa Intelligence Layer (Build 2) | ⬜ Weeks 21–28 |

---

## What Phase 0 Delivered (Complete)

- ✅ Python installed (3.14)
- ✅ VS Code + Claude Code extension installed
- ✅ GitHub repo created: `theroyalcrate/ResellOS`
- ✅ Gmail infrastructure: personal Gmail filters → ResellOS Gmail → ResellOS-Invoices label
- ✅ Agent 1A: LEGO invoice PDF parser — tested on 5 real invoices
  - Handles: standard orders, GWP items, discount column, insider points, gift card payment, credit card payment, split shipments
  - Currently: prints parsed data to console (not yet writing to database)
  - Known gap: captures LEGO `article_number` (e.g. 6378942) but not public `set_number` (e.g. 10242) — resolution pending (Brickset API, Rebrickable API, or LEGO catalog mapping — tracked as future ADR)
- ✅ Architecture document complete (9-table schema, 14-agent map, cost basis engine, tax recovery system, onboarding flow, tech stack, data flow)

---

## The 9-Table Database Schema

```
orders              — one row per order (order_id, retailer, date, totals, payment method, status)
line_items          — one row per set per order (article_number, set_number, qty, price, GWP flag, tax)
inventory           — one row per physical unit (unit_id → line_item, status, true_cost_basis, location)
sales               — one row per unit sold (unit_id, platform, sale_date, gross, fees, net_proceeds)
gift_cards          — retailer-tabbed ledger (face_value, price_paid, discount_%, last_4, status)
rewards_transactions — earn and spend events per retailer pool
cashback_transactions — Rakuten earn and allocation events
gwp                 — GWP units (auto-identified from invoice, tracks net proceeds on sale)
tax_recovery        — per-unit recovery tracking (eligible → filed → reimbursed)
```

---

## The 14 Agents (Current Plan)

| # | Name | Phase | Status |
|---|---|---|---|
| 1A | LEGO Invoice Parser | P0 | ✅ Built — needs DB connection |
| 1B | Walmart/Kohl's/B&N receipt parser | P1 | ⬜ |
| 2 | Manual order entry | P1 | ⬜ |
| 3 | Shipping confirmation reader | P1 | ⬜ |
| 4 | Cost basis engine | P1 | ⬜ |
| 5 | Tax allocation engine | P2 | ⬜ |
| 6 | Rewards pool manager | P1 | ⬜ |
| 7 | Cashback pool manager | P1 | ⬜ |
| 8 | GWP allocation engine | P2 | ⬜ |
| 9 | Sales importer | P3 | ⬜ |
| 10 | Tax recovery report generator | P3 | ⬜ |
| 11 | Google Sheets sync | P4 | ⬜ |
| 12 | Performance dashboard | P4 | ⬜ |
| 13 | Keepa intelligence layer | P7 (Build 2) | ⬜ Premium |
| 14 | Specific identification engine | P7 (Build 2) | ⬜ Premium |

**Planned additions (not yet in master doc):**
- Agent 15: AI query layer — natural language interface to the database (read-only)
- FastAPI local endpoint: Chrome capture socket for order data at point of purchase
- APScheduler: internal scheduling backbone for automated agent runs

---

## Cost Basis — Four Layers

Every unit in inventory carries a `true_cost_basis` calculated across four layers:

1. **Invoice total** — base purchase price including tax (immediate)
2. **Gift card discount** — applied at invoice import (immediate)
3. **Retailer rewards** — calculated at import, held in pool, applied when spent (deferred)
4. **Rakuten cashback** — calculated at import, applied when quarterly payout received (deferred)
5. **GWP net proceeds** — allocated to paid sets on the same order when GWP sells (deferred)

The current tracker does not calculate true cost basis. This is the core value of ResellOS.

---

## Tonight's Session Plan

### Session S01 — Database Creation (60–90 min)
**Goal:** Create all 9 tables in SQLite. Verify structure. Commit to GitHub.

**File to create:** `setup_database.py`

**What it does:**
- Creates `resell_os.db` in the project root
- Creates all 9 tables with correct schema, types, constraints, foreign keys, and indexes
- Prints confirmation of each table created
- Idempotent — safe to run again without destroying existing data (`CREATE TABLE IF NOT EXISTS`)

**Key schema decisions:**
- `inventory.true_cost_basis` starts NULL, updated by Agent 4 as layers complete
- `inventory.tax_recovery_status`: not_eligible | eligible | claimed | reimbursed
- `line_items.article_number` = LEGO internal (e.g. 6378942), `set_number` = public (e.g. 10242) — set_number may be null initially pending API resolution
- `orders.status`: pending_invoice | active | complete
- All monetary values: REAL (not INTEGER cents — simpler for this use case)
- FIFO enforced by `purchase_date` ordering on inventory queries, not a stored field

**Verify before moving to S02:**
- [ ] `resell_os.db` exists in project root
- [ ] All 9 tables visible in DB Browser or via `sqlite3` CLI `.tables`
- [ ] Foreign key relationships intact
- [ ] Committed to GitHub

---

### Session S02 — Connect Agent 1A to Database (90–120 min)
**Goal:** Parsed invoice data writes to `orders` and `line_items` tables instead of printing to console.

**What changes in Agent 1A:**
- Add `sqlite3` connection at top of parser
- After successful parse, write order record to `orders` table
- Write one row per set to `line_items` table
- Match to existing order by `order_id` if already manually entered (status: pending_invoice)
- GWP items write to both `line_items` (with `is_gwp = TRUE`) and `gwp` table
- Parser flags uncertainty — never guesses, never writes partial data

**Test:** Run all 5 real invoices through updated Agent 1A. Verify every field in DB.

---

### Session S03 — Verify and Debug (60–90 min)
**Goal:** Full verification pass. Commit clean code.

- Run all 5 test invoices end to end
- Check GWP flags, discount column, insider points, payment method
- Verify `line_items.tax` is captured per line
- Fix anything that breaks
- Commit to GitHub with descriptive message

---

## Open Architecture Decisions

These are unresolved and will need ADRs before the affected agents are built:

| # | Decision | Urgency | Blocks |
|---|---|---|---|
| ADR-pending | LEGO article_number → set_number mapping (Brickset vs Rebrickable vs LEGO catalog) | Medium | sets metadata table, intelligence layer |
| ADR-010 | Chrome capture endpoint — FastAPI local socket for order capture at LEGO.com order screen | Low | future Phase 3+ automation |
| ADR-011 | Event bus / internal message queue — how agents trigger each other in full automation | Low | Phase 3+ |
| ADR-012 | External data abstraction layer — Keepa, BrickLink API, eBay API as modular plugs | Low | Phase 7 |
| ADR-013 | `sets` metadata table — MSRP, theme, part count, retirement status, price history | Medium | intelligence layer, scoring model |
| ADR-014 | Scoring model config — buy/hold/liquidate recommendation engine | Low | Phase 7 |
| ADR-015 | AI query layer (Agent 15) — read-only natural language interface to ResellOS data | Low | Phase 7+ |

---

## Build Rules — Non-Negotiable

1. **One session, one agent.** Complete and verify before starting the next.
2. **Commit to GitHub after every working build.** Never lose working code between sessions.
3. **Never guess on data.** If the parser is uncertain, it flags the field and stops — it does not write partial or assumed data to the database.
4. **Wrong data in the cost basis engine is worse than no data.** Errors compound silently across every downstream calculation.
5. **Understanding over speed.** If something isn't clear, stop and understand it before writing code.
6. **Test against real invoices.** The 5 test invoices from Phase 0 are the baseline. Every agent that touches invoice data must pass all 5.
7. **Sheets is the view — SQLite is the truth.** All data entry and modification through the OS only. Sheets is read-only.
8. **Flag open decisions, don't resolve them in code.** If an architectural question comes up mid-session, log it as a pending ADR and continue with the safest assumption.

---

## File Structure (Current)

```
ResellOS/
├── agent_1a_invoice_parser.py    ← Agent 1A (working, needs DB connection)
├── resell_os.db                  ← (will exist after S01)
├── setup_database.py             ← (will exist after S01)
├── test_invoices/                ← 5 real LEGO invoice PDFs for testing
├── .gitignore                    ← venv/, *.db (local only), secrets
├── requirements.txt              ← pdfplumber, sqlite3 (stdlib), future deps
└── README.md                     ← Project overview
```

---

## Quick Reference — Key Agent Outputs

| Agent | Reads | Writes |
|---|---|---|
| 1A LEGO parser | Invoice PDF from Gmail | orders, line_items, gwp |
| 2 Manual entry | User input | orders (pending_invoice status) |
| 3 Shipping reader | Shipping confirmation email | orders (tracking number) |
| 4 Cost basis engine | orders, line_items, gift_cards, rewards, cashback, gwp | inventory.true_cost_basis |
| 5 Tax allocation | line_items | line_items.tax, tax_recovery_eligible flag |
| 6 Rewards pool | User input (rate), orders | rewards_transactions |
| 7 Cashback pool | User input (rate), Rakuten payout | cashback_transactions |
| 8 GWP allocator | User input (net proceeds), gwp, inventory | inventory.true_cost_basis (adjustment) |
| 9 Sales importer | Platform CSV exports | sales, inventory.status → sold |
| 10 Tax recovery | sales, inventory, tax_recovery | tax_recovery report (PDF/CSV) |
| 11 Sheets sync | All tables | Google Sheets tabs |
| 12 Performance | sales, inventory, orders | Dashboard aggregate views |

---

*ResellOS — Architecture v1.0 · LEGO vertical first · Designed to generalize*
*Built from 15 months live experience · theroyalcrate/ResellOS*
